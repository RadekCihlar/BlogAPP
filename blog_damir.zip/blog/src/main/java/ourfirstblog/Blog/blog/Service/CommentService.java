package ourfirstblog.Blog.blog.Service;

import org.springframework.stereotype.Service;
import ourfirstblog.Blog.blog.Model.Comment;

import java.util.List;

@Service
public interface CommentService {
    void saveComment(Comment comment);
    void delete(Comment comment);

    void save(Comment comment);
}